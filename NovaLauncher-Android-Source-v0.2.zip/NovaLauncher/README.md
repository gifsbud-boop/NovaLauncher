# Nova Launcher — Android starter project

A Kotlin + Jetpack Compose Android launcher foundation with a futuristic purple/blue UI.

## Included and working
- Android application shell and bottom navigation
- Official Mojang version manifest retrieval
- Release/snapshot/old-version listing (first 250 manifest entries)
- Selection of a Minecraft version
- Automatic download of the selected version's client JAR, eligible library artifacts, asset index and asset objects\n- SHA-1/size validation and reuse of already-valid files
- Local in-memory profile selection, RAM preference and resolution controls
- Activity log and loading/error states

## Important status: not yet a playable Minecraft launcher
This project now installs Mojang version metadata, the client JAR, eligible library artifacts, the asset index and asset objects into its private app directory, validating SHA-1 and/or file sizes and reusing valid downloads. Downloads are sequential and currently report the current item rather than byte-level progress. It does **not** yet install Android-compatible native libraries, authenticate Microsoft/Xbox/Minecraft accounts, install an Android Java runtime, provide the OpenGL/Vulkan translation layer, or launch the game. The Android runtime/rendering bridge is still required before Play can work. Forge/Fabric/Quilt support is not implemented yet.

Minecraft game files are not bundled. Users must own Minecraft Java Edition and sign in through an authorized Microsoft flow before a full launcher can download/play it.

## Build
1. Install Android Studio (current stable) with Android SDK Platform 35 and JDK 17 or newer.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Connect an Android device with USB debugging enabled or start an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

APK output (after a successful local build):
`app/build/outputs/apk/debug/app-debug.apk`

Or run:
```bash
./gradlew assembleDebug
```
A Gradle wrapper is not included in this archive; Android Studio can generate/use its Gradle installation.

## Next engineering milestones
1. Persist profiles/settings in DataStore or Room.
2. Implement Microsoft device-code/OAuth flow and Minecraft entitlement/profile validation using a registered client ID.
4. Build a verified Mojang asset/library installer with SHA-1 checks and resumable downloads.
5. Integrate a maintained Android Java runtime distribution.
6. Integrate an Android-compatible Minecraft rendering/runtime layer and lifecycle/process management.
7. Add Fabric/Forge installer compatibility and touch controls.

## License
This starter code is provided for learning and development. Minecraft is a trademark of Mojang Studios/Microsoft; this project is unofficial and not affiliated with them.
