package com.nova.launcher

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale

/**
 * Downloads Mojang's official version metadata, client JAR, library artifacts
 * and asset objects. Native classifiers are intentionally not installed here:
 * desktop Linux natives are not Android-compatible.
 */
class MinecraftInstaller(context: Context) {
    private val gameDir = File(context.filesDir, "minecraft").apply { mkdirs() }

    data class Result(val version: String, val filesDownloaded: Int, val assetsDownloaded: Int)

    fun install(versionId: String, onProgress: (String) -> Unit): Result {
        require(versionId.matches(Regex("[A-Za-z0-9._-]{1,80}"))) { "Invalid version id" }

        val manifest = readJson(URL("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"))
        val versions = manifest.getJSONArray("versions")
        var metadataUrl: String? = null
        for (i in 0 until versions.length()) {
            val item = versions.getJSONObject(i)
            if (item.optString("id") == versionId) {
                metadataUrl = item.getString("url")
                break
            }
        }
        val versionUrl = metadataUrl ?: error("Version $versionId was not found in Mojang's manifest")
        onProgress("Downloading $versionId metadata…")
        val metadata = readJson(URL(versionUrl))
        val versionsDir = File(gameDir, "versions/$versionId").apply { mkdirs() }
        val metadataFile = File(versionsDir, "$versionId.json")
        metadataFile.writeText(metadata.toString())

        var downloaded = 0
        val client = metadata.optJSONObject("downloads")?.optJSONObject("client")
            ?: error("This version has no downloadable client JAR")
        onProgress("Downloading Minecraft client…")
        download(
            client.getString("url"),
            File(versionsDir, "$versionId.jar"),
            client.optString("sha1"),
            client.optLong("size", -1)
        )
        downloaded++

        val libraries = metadata.optJSONArray("libraries")
        if (libraries != null) {
            val total = libraries.length()
            for (i in 0 until total) {
                val lib = libraries.getJSONObject(i)
                if (!allowedByRules(lib.optJSONArray("rules"))) continue
                val artifact = lib.optJSONObject("downloads")?.optJSONObject("artifact") ?: continue
                val relative = artifact.optString("path")
                if (relative.isBlank()) continue
                val target = safeChild(File(gameDir, "libraries"), relative)
                onProgress("Library ${i + 1}/$total: ${target.name}")
                download(
                    artifact.getString("url"),
                    target,
                    artifact.optString("sha1"),
                    artifact.optLong("size", -1)
                )
                downloaded++
            }
        }

        var assetsDownloaded = 0
        val assetIndex = metadata.optJSONObject("assetIndex")
        if (assetIndex != null) {
            val indexId = assetIndex.getString("id")
            val indexFile = File(gameDir, "assets/indexes/$indexId.json")
            onProgress("Downloading asset index…")
            download(
                assetIndex.getString("url"),
                indexFile,
                assetIndex.optString("sha1"),
                assetIndex.optLong("size", -1)
            )
            val objects = JSONObject(indexFile.readText()).optJSONObject("objects")
                ?: JSONObject()
            val iterator = objects.keys()
            val totalAssets = objects.length()
            while (iterator.hasNext()) {
                val name = iterator.next()
                val obj = objects.getJSONObject(name)
                val hash = obj.getString("hash").lowercase(Locale.ROOT)
                require(hash.matches(Regex("[a-f0-9]{40}"))) { "Invalid asset hash" }
                val target = File(gameDir, "assets/objects/${hash.substring(0, 2)}/$hash")
                if (!isValid(target, hash, obj.optLong("size", -1))) {
                    onProgress("Asset ${assetsDownloaded + 1}/$totalAssets")
                    download(
                        "https://resources.download.minecraft.net/${hash.substring(0, 2)}/$hash",
                        target, hash, obj.optLong("size", -1)
                    )
                }
                assetsDownloaded++
            }
        }
        return Result(versionId, downloaded, assetsDownloaded)
    }

    fun gameDirectory(): File = gameDir

    private fun readJson(url: URL): JSONObject {
        val connection = url.openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "NovaLauncher/0.2")
        try {
            return JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        } finally {
            connection.disconnect()
        }
    }

    private fun download(url: String, target: File, sha1: String, expectedSize: Long) {
        target.parentFile?.mkdirs()
        if (isValid(target, sha1, expectedSize)) return

        val temp = File(target.parentFile, target.name + ".part")
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "NovaLauncher/0.2")
        try {
            connection.connect()
            require(connection.responseCode in 200..299) {
                "Download failed (${connection.responseCode}): $url"
            }
            connection.inputStream.use { input ->
                temp.outputStream().buffered().use { output -> input.copyTo(output) }
            }
            if (!isValid(temp, sha1, expectedSize)) {
                temp.delete()
                error("Integrity check failed for ${target.name}")
            }
            if (target.exists()) target.delete()
            check(temp.renameTo(target)) { "Could not finalize ${target.name}" }
        } finally {
            connection.disconnect()
            if (temp.exists()) temp.delete()
        }
    }

    private fun isValid(file: File, sha1: String, expectedSize: Long): Boolean {
        if (!file.isFile) return false
        if (expectedSize >= 0 && file.length() != expectedSize) return false
        if (sha1.isNotBlank()) return sha1(file).equals(sha1, ignoreCase = true)
        return expectedSize >= 0
    }

    private fun sha1(file: File): String {
        val digest = MessageDigest.getInstance("SHA-1")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun safeChild(base: File, relative: String): File {
        val root = base.canonicalFile
        val child = File(root, relative).canonicalFile
        require(child.path.startsWith(root.path + File.separator)) { "Unsafe library path" }
        return child
    }

    private fun allowedByRules(rules: org.json.JSONArray?): Boolean {
        if (rules == null) return true
        var allowed = false
        for (i in 0 until rules.length()) {
            val rule = rules.getJSONObject(i)
            val os = rule.optJSONObject("os")
            val osName = os?.optString("name")
            val matchesOs = osName == null || osName == "linux"
            val archRegex = os?.optString("arch").orEmpty()
            val matchesArch = archRegex.isBlank() ||
                Regex(archRegex).containsMatchIn(System.getProperty("os.arch").orEmpty())
            val matches = matchesOs && matchesArch
            when (rule.optString("action")) {
                "allow" -> if (matches) allowed = true
                "disallow" -> if (matches) allowed = false
            }
        }
        return allowed
    }
}
