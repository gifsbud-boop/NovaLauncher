package com.nova.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Ink = Color(0xFF090B18)
private val Panel = Color(0xFF151A30)
private val Violet = Color(0xFF9165FF)
private val Cyan = Color(0xFF45D9F5)
private val Muted = Color(0xFF9AA4C4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaTheme { NovaApp() } }
    }
}

data class GameVersion(val id: String, val type: String, val url: String)

class NovaViewModel(application: Application) : AndroidViewModel(application) {
    var versions by mutableStateOf<List<GameVersion>>(emptyList())
        private set
    var selected by mutableStateOf("")
    var loading by mutableStateOf(false)
    var message by mutableStateOf("Ready")
    var tab by mutableStateOf("Home")
    var ram by mutableFloatStateOf(3f)
    var resolution by mutableStateOf("1280 × 720")
    var profile by mutableStateOf("Survival")
    var logs by mutableStateOf(listOf("Nova initialized.", "Game runtime is not installed."))

    init { refreshVersions() }


    fun refreshVersions() {
        viewModelScope.launch {
            loading = true
            message = "Fetching official version manifest…"
            try {
                val result = withContext(Dispatchers.IO) {
                    val connection = URL("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")
                        .openConnection() as HttpURLConnection
                    connection.connectTimeout = 12000
                    connection.readTimeout = 12000
                    try {
                        val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                        val array = json.getJSONArray("versions")
                        buildList {
                            for (i in 0 until minOf(array.length(), 250)) {
                                val item = array.getJSONObject(i)
                                add(GameVersion(item.getString("id"), item.getString("type"), item.getString("url")))
                            }
                        }
                    } finally { connection.disconnect() }
                }
                versions = result
                if (selected.isBlank()) selected = result.firstOrNull { it.type == "release" }?.id.orEmpty()
                message = "Loaded ${result.size} versions from Mojang."
                logs = (logs + message).takeLast(30)
            } catch (e: Exception) {
                message = "Could not load versions: ${e.message ?: "network error"}"
                logs = (logs + message).takeLast(30)
            } finally { loading = false }
        }
    }

    fun prepareSelectedVersion() {
        val version = versions.firstOrNull { it.id == selected } ?: run {
            message = "Choose a version first."
            return
        }
        viewModelScope.launch {
            loading = true
            message = "Starting installer…"
            try {
                val app = getApplication<Application>()
                val result = withContext(Dispatchers.IO) {
                    MinecraftInstaller(app).install(version.id) { stage ->
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            message = stage
                        }
                    }
                }
                message = "Installed ${result.version}: ${result.filesDownloaded} client/library files and ${result.assetsDownloaded} assets."
                logs = (logs + message + " Android Java/graphics runtime is still required to play.").takeLast(30)
            } catch (e: Exception) {
                message = "Install failed: ${e.message ?: "unknown error"}"
                logs = (logs + message).takeLast(30)
            } finally {
                loading = false
            }
        }
    }

}

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Violet,
            secondary = Cyan, onBackground = Color.White, onSurface = Color.White
        ), content = content
    )
}

@Composable
fun NovaApp(vm: NovaViewModel = viewModel()) {
    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Panel) {
            listOf("Home", "Versions", "Profiles", "Settings", "Logs").forEach { item ->
                NavigationBarItem(
                    selected = vm.tab == item,
                    onClick = { vm.tab = item },
                    icon = {
                        Icon(when(item) {
                            "Versions" -> Icons.Default.ViewList
                            "Profiles" -> Icons.Default.Person
                            "Settings" -> Icons.Default.Settings
                            "Logs" -> Icons.Default.Terminal
                            else -> Icons.Default.Home
                        }, contentDescription = item)
                    },
                    label = { Text(item) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Cyan, selectedTextColor = Cyan,
                        indicatorColor = Violet.copy(alpha = .18f),
                        unselectedIconColor = Muted, unselectedTextColor = Muted
                    )
                )
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF15102B), Ink, Ink))
        ).padding(padding).padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NOVA", color = Color.White, fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.headlineMedium)
                    Text("MINECRAFT JAVA • ANDROID", color = Cyan,
                        style = MaterialTheme.typography.labelSmall)
                }
                Surface(shape = RoundedCornerShape(50), color = Violet.copy(alpha = .18f)) {
                    Text("PREVIEW 0.1", color = Violet, modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.labelSmall)
                }
            }
            when (vm.tab) {
                "Home" -> HomeScreen(vm)
                "Versions" -> VersionsScreen(vm)
                "Profiles" -> ProfilesScreen(vm)
                "Settings" -> SettingsScreen(vm)
                else -> LogsScreen(vm)
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(14.dp))
}

@Composable
fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        content = { Column(Modifier.padding(16.dp), content = content) })
}

@Composable
fun HomeScreen(vm: NovaViewModel) {
    Header("Welcome back", "Your worlds. Your settings. Your Nova.")
    PanelCard {
        Text("CURRENT PROFILE", color = Cyan, style = MaterialTheme.typography.labelSmall)
        Text(vm.profile, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Selected version: ${vm.selected.ifBlank { "Not selected" }}", color = Muted)
        Text("Launcher status: ${vm.message}", color = Muted, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(14.dp))
        Button(onClick = { vm.prepareSelectedVersion() }, modifier = Modifier.fillMaxWidth(),
            enabled = !vm.loading && vm.selected.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
            Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp))
            Text("DOWNLOAD & INSTALL")
        }
        Text("Downloads Minecraft files automatically. Playing still needs the Android Java + graphics runtime.",
            color = Muted, style = MaterialTheme.typography.bodySmall)
    }
    Spacer(Modifier.height(14.dp))
    PanelCard {
        Text("QUICK ACCESS", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickChip("Versions", Icons.Default.ViewList, Modifier.weight(1f)) { vm.tab = "Versions" }
            QuickChip("Profiles", Icons.Default.Person, Modifier.weight(1f)) { vm.tab = "Profiles" }
            QuickChip("Settings", Icons.Default.Tune, Modifier.weight(1f)) { vm.tab = "Settings" }
        }
    }
}

@Composable
fun QuickChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, action: () -> Unit) {
    Surface(modifier.clickable(onClick = action), color = Color(0xFF242344),
        shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Cyan)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun VersionsScreen(vm: NovaViewModel) {
    Header("Game versions", "Official Mojang version manifest")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("${vm.versions.size} entries", color = Muted, modifier = Modifier.weight(1f))
        TextButton(onClick = { vm.refreshVersions() }, enabled = !vm.loading) {
            Icon(Icons.Default.Refresh, null); Text("Refresh")
        }
    }
    if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cyan)
    Text("Selected: ${vm.selected.ifBlank { "None" }}", color = Cyan)
    Spacer(Modifier.height(8.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(vm.versions) { version ->
            Surface(color = if (vm.selected == version.id) Color(0xFF302451) else Panel,
                shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
                    .clickable { vm.selected = version.id }) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(version.id, fontWeight = FontWeight.SemiBold)
                        Text(version.type.uppercase(), color = Muted,
                            style = MaterialTheme.typography.labelSmall)
                    }
                    if (vm.selected == version.id) Icon(Icons.Default.CheckCircle, null, tint = Cyan)
                }
            }
        }
    }
}

@Composable
fun ProfilesScreen(vm: NovaViewModel) {
    Header("Profiles", "Separate settings for different play styles")
    listOf("Survival", "Creative", "Modded", "Performance").forEach { name ->
        Surface(color = if (vm.profile == name) Color(0xFF302451) else Panel,
            shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
                .padding(bottom = 9.dp).clickable { vm.profile = name }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Folder, null, tint = Violet)
                Spacer(Modifier.width(12.dp))
                Text(name, modifier = Modifier.weight(1f))
                if (vm.profile == name) Icon(Icons.Default.Check, null, tint = Cyan)
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: NovaViewModel) {
    Header("Settings", "Tune the launcher configuration")
    PanelCard {
        Text("MEMORY ALLOCATION", fontWeight = FontWeight.Bold)
        Text("${vm.ram.toInt()} GB", color = Cyan)
        Slider(value = vm.ram, onValueChange = { vm.ram = it },
            valueRange = 1f..8f, steps = 6)
        Text("Available RAM depends on your device. Avoid allocating more than the system can spare.",
            color = Muted, style = MaterialTheme.typography.bodySmall)
    }
    Spacer(Modifier.height(12.dp))
    PanelCard {
        Text("RENDER RESOLUTION", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        listOf("854 × 480", "1280 × 720", "1600 × 900").forEach {
            Row(Modifier.fillMaxWidth().clickable { vm.resolution = it }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(it, Modifier.weight(1f))
                RadioButton(selected = vm.resolution == it, onClick = { vm.resolution = it })
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    PanelCard {
        Text("ACCOUNT", fontWeight = FontWeight.Bold)
        Text("Microsoft sign-in is not configured in this preview build.", color = Muted)
    }
}

@Composable
fun LogsScreen(vm: NovaViewModel) {
    Header("Activity log", "Recent launcher events")
    PanelCard {
        vm.logs.asReversed().forEach {
            Text("› $it", color = Muted, style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(vertical = 4.dp))
        }
    }
}
