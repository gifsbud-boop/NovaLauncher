package com.glasses;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.irisshaders.iris.api.v0.IrisApi;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class GlassesClient implements ClientModInitializer {
    public enum Mode { GLASSES, ALL }

    public static Mode mode = Mode.GLASSES;
    private static KeyBinding modeKey;
    private static Boolean lastApplied = null;

    @Override
    public void onInitializeClient() {
        modeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.glasses.mode", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.glasses"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (modeKey.wasPressed()) {
                mode = (mode == Mode.GLASSES) ? Mode.ALL : Mode.GLASSES;
                if (client.player != null)
                    client.player.sendMessage(Text.literal("Shader mode: " + (mode == Mode.ALL ? "ALL" : "GLASSES \uD83D\uDD76")), true);
            }
            if (client.player == null || !FabricLoader.getInstance().isModLoaded("iris")) return;

            boolean wearing = client.player.getEquippedStack(EquipmentSlot.HEAD).isOf(GlassesMod.GLASSES);
            boolean want = (mode == Mode.ALL) || wearing;
            if (lastApplied == null || lastApplied != want) {
                lastApplied = want;
                IrisApi.getInstance().getConfig().setShadersEnabledAndApply(want);
            }
        });
    }
}
