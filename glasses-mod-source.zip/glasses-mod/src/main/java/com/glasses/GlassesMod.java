package com.glasses;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.*;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

public class GlassesMod implements ModInitializer {
    public static final String ID = "glasses";

    public static final ArmorMaterial MATERIAL = new ArmorMaterial() {
        public int getDurability(ArmorItem.Type t) { return 100; }
        public int getProtection(ArmorItem.Type t) { return 0; }
        public int getEnchantability() { return 5; }
        public SoundEvent getEquipSound() { return SoundEvents.ITEM_ARMOR_EQUIP_GENERIC; }
        public Ingredient getRepairIngredient() { return Ingredient.ofItems(Items.GLASS_PANE); }
        public String getName() { return "glasses:glasses"; }
        public float getToughness() { return 0; }
        public float getKnockbackResistance() { return 0; }
    };

    public static final Item GLASSES = new ArmorItem(MATERIAL, ArmorItem.Type.HELMET, new FabricItemSettings().maxCount(1));

    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM, new Identifier(ID, "glasses"), GLASSES);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(GLASSES));
    }
}
